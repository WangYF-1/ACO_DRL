本文件夹为性能测试工具文件夹，共包括2个文件，以及2个文件夹

HELP.md为项目安装配置说明文件、pom.xml文件为项目依赖配置文件

Src为项目源代码目录，target目录为项目已编译代码文件目录

本项目主程序为 src/main/java/org/fisco_backend/FiscoApplication.java文件 

运行程序前请先查看HELP.md文件