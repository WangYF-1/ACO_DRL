package org.fisco;

import org.fisco.bcos.sdk.BcosSDK;
import org.fisco.bcos.sdk.abi.ABICodecException;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.fisco.bcos.sdk.transaction.model.exception.TransactionBaseException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SpringBootTest
class FiscoApplicationTests {
    private final String[] address= {  //各群组的预编译合约地址
            "0x29d23012c41ae938a1ed4e4677e09332aed8a9b7",//group2 101个节点
            "0xa03e81ec49a3199190ed79732ebc9344d03f9c8a",//group3-12 11个节点
            "0x385f41edaddd9cf2149a83f11c51ece2403c9645",
            "0xd50fcd4234337ebd591fdeb99401622f6dc2651a",
            "0x1914bc4f040e2c12c7bccd5a729e32621b4d1fd8",
            "0xc0ee03129bbb8cf50b760038de040597f6f0681a",
            "0xf20808265d8073ea036acb9e8d21510702ffee04",
            "0x508fcbf0dae2cd4ac5865039f9607e44de03eecb",
            "0xd8cc982386e2999672f28a91c033872cb0047ff5",
            "0x762c410b25a31bd5fd291cbf78c50b4f6bff044b",
            "0x19517eafe431e35d868a731d8b64fe01df3ac6e3"
    };
    public final String configFile ="src/main/resources/config.toml";
    final Path path= Path.of("/Users/wbq/Desktop/java/Fisco/src/main/resources/File");//测试文件存放位置
    BcosSDK sdk;
    List<Client> clients;
    List<AssembleTransactionProcessor> processors;
    List<Object> params;
    String Content;
    @BeforeEach
    public void init() throws Exception {
        clients=new ArrayList<>();
        sdk = BcosSDK.build(configFile);
        for (int i=2;i<13;i++){
            clients.add(sdk.getClient(i)); //0-10
        }
        processors=new ArrayList<>();
        for (int i=2;i<13;i++){
            CryptoKeyPair keyPair = clients.get(i-2).getCryptoSuite().createKeyPair();
            AssembleTransactionProcessor transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(clients.get(i-2),keyPair,"src/main/resources/abi/", "src/main/resources/bin/");
            processors.add(transactionProcessor); //0-10
        }
        String filePath = path +"/Test1.txt"; //文件 1:10K 2:20K
        StringBuilder builder=new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // 处理每一行
                builder.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        Content=builder.toString();
        params = new ArrayList<>();
        params.add("001");
        params.add(Content);
        params.add(0);
        params.add(0);
        Date date=new Date();
        SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        params.add(dateFormat.format(date));
    }

    @Test
    void insertFile_MultipleGroups_Multithreading() throws InterruptedException {
        String MethodName="insert";
        final int totalThread = 100;//线程数量，即需要发送的总交易数
        CountDownLatch latch = new CountDownLatch(totalThread);
        ExecutorService executor = Executors.newFixedThreadPool(100); // 使用线程池管理线程
        // 获取开始时间（毫秒）
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < totalThread; i++) {
            int finalI = i;
            executor.submit(() -> {
                try {
                    int Group_id= finalI %10;//0-9                                                                       1～10
                    processors.get(Group_id+1).sendTransactionAndGetResponseByContractLoader("File", address[Group_id+1], MethodName, params);
                } catch (ABICodecException | TransactionBaseException e) {
                    throw new RuntimeException(e);
                } finally {
                    latch.countDown(); // 执行完成后，计数减一
                }
            });
        }

        latch.await(); // 等待所有子线程执行完成
        // 获取结束时间（毫秒）
        long endTime = System.currentTimeMillis();
        // 计算耗时
        long timeElapsed = endTime - startTime;

        System.out.println("程序运行耗时（毫秒）：" + timeElapsed);

        executor.shutdown(); // 关闭线程池
    }
    @Test
    void insertFile_Single_Multithreading() throws InterruptedException {
        String MethodName="insert";
        final int totalThread = 100;//线程数量
        CountDownLatch latch = new CountDownLatch(totalThread);
        ExecutorService executor = Executors.newFixedThreadPool(100); // 使用线程池管理线程
        // 获取开始时间（毫秒）
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < totalThread; i++) {
            executor.submit(() -> {
                try {
                    int Group_id= 1;
                    processors.get(0).sendTransactionAndGetResponseByContractLoader("File", address[0], MethodName, params);
                } catch (ABICodecException | TransactionBaseException e) {
                    throw new RuntimeException(e);
                } finally {
                    latch.countDown(); // 执行完成后，计数减一
                }
            });
        }

        latch.await(); // 等待所有子线程执行完成
        // 获取结束时间（毫秒）
        long endTime = System.currentTimeMillis();
        // 计算耗时
        long timeElapsed = endTime - startTime;

        System.out.println("程序运行耗时（毫秒）：" + timeElapsed);

        executor.shutdown(); // 关闭线程池
    }
}
