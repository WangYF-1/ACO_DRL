package org.fisco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiscoApplication {

    public static void main(String[] args) {
        SpringApplication.run(FiscoApplication.class, args);
    }

}
