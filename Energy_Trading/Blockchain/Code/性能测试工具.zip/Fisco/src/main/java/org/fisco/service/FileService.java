package org.fisco.service;

import org.fisco.bcos.sdk.BcosSDK;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.client.protocol.response.TotalTransactionCount;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.fisco.bcos.sdk.transaction.model.dto.TransactionResponse;
import org.fisco.entity.transaction;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
public class FileService {
    private final String[] address= {  //各群组的预编译合约地址
            "0x910771bd2bcfca2636e85e3e920c4c6e6bc34b8f", //group2 101个节点
            "0x90bd46148d03bdc87c7f195c7c8cc55282d3b62f", //group3-12 11个节点
            "0xdabf904a27fd0e7d7bc2a28ac13ad0ad43079281",
            "0xbd5e22c885e9425aeb96d5af1ea25f8ce39eeb77",
            "0xcf378c60a5c3964b7662be6cb1b3788d3ea7e214",
            "0xe38df4513114c4c1a10caeed93c295172b9659aa",
            "0xce1976a8d2740eb9300fcb4e054e1b40f65e7e4c",
            "0x150398c378f8e02254c30f32af7cd449c50d794d",
            "0x2030406785d7ec4254f160ee56e40759308110bc",
            "0xcf4d3909f1f3c85e7f32d1d3986e47a0fd768ee0",
            "0xc61cbfcf99422b986f613a05c4c4f46c64d2af68"
    };
    public final String configFile ="src/main/resources/config.toml";
    BcosSDK sdk;
    List<Client> clients;
    {
        clients=new ArrayList<>();
        sdk = BcosSDK.build(configFile);
        for (int i=2;i<12;i++){
            clients.add(sdk.getClient(i));
        }
    }
    public boolean insertFile(int Group_id,String Agency_id,String Content,int Round) throws Exception {
        // 获取Client对象，此处传入的群组ID为1
        // 构造AssembleTransactionProcessor对象，需要传入client对象，CryptoKeyPair对象和abi、binary文件存放的路径。abi和binary文件需要在上一步复制到定义的文件夹中。
        CryptoKeyPair keyPair = clients.get(Group_id-1).getCryptoSuite().createKeyPair();
        AssembleTransactionProcessor transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(clients.get(Group_id-1), keyPair, "src/main/resources/abi/", "src/main/resources/bin/");

        // 创建调用交易函数的参数，此处为传入一个参数
        List<Object> params = new ArrayList<>();
        String MethodName="insert";
        params.add(Agency_id);
        params.add(Content);
        params.add(Round);
        params.add(0);
        Date date=new Date();
        SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        params.add(dateFormat.format(date));

        // 调用HelloWorld合约，合约地址为helloWorldAddress， 调用函数名为『set』，函数参数类型为params
        TransactionResponse transactionResponse = transactionProcessor.sendTransactionAndGetResponseByContractLoader("File", address[Group_id-1], MethodName, params);
        if(Objects.equals(transactionResponse.getValues(), "1"))
            return true;
        else
            System.out.println(transactionResponse.getReturnObject());
        return false;
    }
    public boolean insertFile(String Agency_id,String Content,int Round,int Reward) throws Exception {
        // 构造AssembleTransactionProcessor对象，需要传入client对象，CryptoKeyPair对象和abi、binary文件存放的路径。abi和binary文件需要在上一步复制到定义的文件夹中。
        CryptoKeyPair keyPair = clients.get(0).getCryptoSuite().createKeyPair();
        AssembleTransactionProcessor transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(clients.get(0), keyPair, "src/main/resources/abi/", "");

        // 创建调用交易函数的参数，此处为传入一个参数
        List<Object> params = new ArrayList<>();
        String MethodName="insert";
        params.add(Agency_id);
        params.add(Content);
        params.add(Round);
        params.add(Reward);
        Date date=new Date();
        SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        params.add(dateFormat.format(date));
        TransactionResponse transactionResponse = transactionProcessor.sendTransactionAndGetResponseByContractLoader("File", address[0], MethodName, params);
        return Objects.equals(transactionResponse.getValues(), "1");
    }
    public boolean updateReward(String Group_id,int Round,int Reward) throws Exception {
        // 构造AssembleTransactionProcessor对象，需要传入client对象，CryptoKeyPair对象和abi、binary文件存放的路径。abi和binary文件需要在上一步复制到定义的文件夹中。
        CryptoKeyPair keyPair = clients.get(Integer.parseInt(Group_id)-1).getCryptoSuite().createKeyPair();
        AssembleTransactionProcessor transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(clients.get(Integer.parseInt(Group_id)-1), keyPair, "src/main/resources/abi/", "");

        // 创建调用交易函数的参数，此处为传入一个参数
        List<Object> params = new ArrayList<>();
        String MethodName="updateReward";
        params.add(Group_id);
        params.add(Round);
        params.add(Reward);
        TransactionResponse transactionResponse = transactionProcessor.sendTransactionAndGetResponseByContractLoader("File", address[Integer.parseInt(Group_id)-1], MethodName, params);
        return true;
    }
    public List<transaction> selectById(int group_id, String agency_id) throws Exception {
        // 获取Client对象，此处传入的群组ID为1
        // 构造AssembleTransactionProcessor对象，需要传入client对象，CryptoKeyPair对象和abi、binary文件存放的路径。abi和binary文件需要在上一步复制到定义的文件夹中。
        CryptoKeyPair keyPair = clients.get(group_id-1).getCryptoSuite().createKeyPair();
        AssembleTransactionProcessor transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(clients.get(group_id-2), keyPair, "src/main/resources/abi/", "");

        // 创建调用交易函数的参数，此处为传入一个参数
        List<Object> params = new ArrayList<>();
        String MethodName="selectById";
        params.add(agency_id);
        TransactionResponse transactionResponse = transactionProcessor.sendTransactionAndGetResponseByContractLoader("File", address[group_id-2],MethodName, params);
        List<Object> object = transactionResponse.getReturnObject();
        List<transaction> transactions = new ArrayList<>();
        List<Object> id = List.of();
        List<Object> round= List.of();
        List<Object> reward= List.of();
        List<Object> time= List.of();
        for (int i = 0; i <object.size() ; i++) {
             ArrayList<Object> array= (ArrayList<Object>) object.get(i);
             if (!array.isEmpty()){
                 switch (i){
                     case 0: id= (List<Object>) array.clone();
                     case 1: round= (List<Object>) array.clone();
                     case 2: reward= (List<Object>) array.clone();
                     case 3: time= (List<Object>) array.clone();
                 }
             }
        }
        for (int i = 0; i < id.size(); i++) {
            transactions.add(new transaction()
                    .setAgency_id((String) id.get(i))
                    .setRound(round.get(i).toString())
                    .setReward(reward.get(i).toString())
                    .setTime((String) time.get(i))
            );
        }
        return transactions;
    }
    public List<Object> selectById_01(int group_id,String agency_id) throws Exception {
        // 获取Client对象，此处传入的群组ID为1
        // 构造AssembleTransactionProcessor对象，需要传入client对象，CryptoKeyPair对象和abi、binary文件存放的路径。abi和binary文件需要在上一步复制到定义的文件夹中。
        CryptoKeyPair keyPair = clients.get(group_id-1).getCryptoSuite().createKeyPair();
        AssembleTransactionProcessor transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(clients.get(group_id-2), keyPair, "src/main/resources/abi/", "");

        // 创建调用交易函数的参数，此处为传入一个参数
        List<Object> params = new ArrayList<>();
        String MethodName="selectById";
        params.add(agency_id);
        TransactionResponse transactionResponse = transactionProcessor.sendTransactionAndGetResponseByContractLoader("File", address[group_id-2],MethodName, params);
        StringBuilder builder = new StringBuilder();
        return transactionResponse.getReturnObject();
    }
    public Object selectByIdAndRound(int group_id,String agency_id,int Round) throws Exception {
        CryptoKeyPair keyPair = clients.get(group_id-2).getCryptoSuite().createKeyPair();
        AssembleTransactionProcessor transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(clients.get(group_id-2), keyPair, "src/main/resources/abi/", "");

        // 创建调用交易函数的参数，此处为传入一个参数
        List<Object> params = new ArrayList<>();
        String MethodName="selectByIdAndRound";
        params.add(agency_id);
        params.add(Round);
        TransactionResponse transactionResponse = transactionProcessor.sendTransactionAndGetResponseByContractLoader("File", address[group_id-2], MethodName, params);
        List<Object> object = transactionResponse.getReturnObject();
        return object.get(3);
    }
    public String getTotalTransactionCount(int Group_id){
        TotalTransactionCount transactionCount = clients.get(Group_id-2).getTotalTransactionCount();
        String blockNumber = transactionCount.getTotalTransactionCount().getBlockNumber();
        int block = Integer.parseInt(blockNumber.substring(2),16);
        String txSum = transactionCount.getTotalTransactionCount().getTxSum();
        int tx = Integer.parseInt(txSum.substring(2),16);
        return block+","+tx;
        //return blockNumber+","+txSum;
    }
}
