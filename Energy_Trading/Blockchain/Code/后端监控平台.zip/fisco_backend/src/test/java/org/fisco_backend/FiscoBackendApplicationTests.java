package org.fisco_backend;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiscoBackendApplicationTests {
}
