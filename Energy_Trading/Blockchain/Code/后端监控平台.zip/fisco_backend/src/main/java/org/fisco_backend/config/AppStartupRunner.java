package org.fisco_backend.config;


import jakarta.annotation.Resource;
import org.fisco_backend.service.AsyncService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @program: fisco_backend
 * @description: 异步配置
 * @author: 王贝强
 * @create: 2024-04-25 19:34
 */
@Component
public class AppStartupRunner implements CommandLineRunner {

    @Resource
    private AsyncService asyncService;

    @Override
    public void run(String... args) throws IOException, InterruptedException {
        asyncService.runAsyncTask();
    }
}
