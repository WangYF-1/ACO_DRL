package org.fisco_backend.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 * @author Ll
 * @description: TODO
 * @date 2024/4/21 下午1:47
 */
@Configuration
@EnableWebMvc
public class WebConfiguration {
}
