package org.fisco_backend.service;

import jakarta.annotation.Resource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @program: fisco_backend
 * @description: 异步文件夹监控
 * @author: 王贝强
 * @create: 2024-04-25 19:08
 */
@Service
public class AsyncService {
    @Resource
    FileService service;
    private volatile int Round = 0;
    private Random random;
    private final int Group=2; //程序上传文件的群组Id

    //程序监控的文件目录
    private final Path path= Path.of("/Users/wbq/Downloads/fisco_backend/src/main/resources/file");
    //private final Path path= Path.of("/home/fisco/Myapp/file");
    public void sendFile(String FileContent) {
        try {
            System.out.println("文件夹监控程序启动");
            if (FileContent!=null)
            {
                Thread getRound= new Thread(()->{
                    try {
                        System.out.println("轮次查询中。。。");
                        List<Object> ret= service.selectById_01(Group, "00"+Group);
                        System.out.println("轮次查询成功。。。");
                        ArrayList<Object> rounds= (ArrayList<Object>) ret.get(1);
                        if (!rounds.isEmpty()) {
                            Round=rounds.size()+1;
                        }
                        else
                            Round=1;
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                });
                getRound.start();
                // 主线程等待新线程结束
                try {
                    getRound.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("模型上传中。。。");
                service.insertFile(Group,"00"+Group,FileContent,Round);
                System.out.println("模型上传成功。。。");
                System.out.println("模型激励值更新中。。。");
                int Reward=random.nextInt(99)+1;
                service.updateReward("00"+Group,Round,Reward);
                System.out.println("模型激励值更新成功。。。");
                System.out.println("监控节点同步数据中。。。");
                service.insertFile("00"+Group,FileContent,Round,Reward);
                System.out.println("监控节点数据同步成功。。。");
            }

        } catch (IOException | InterruptedException ex) {
            System.err.println("An error occurred: " + ex.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Async
    public void runAsyncTask() throws InterruptedException, IOException {
        random=new Random();
        while (true) {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            this.path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE,
                    StandardWatchEventKinds.ENTRY_DELETE,
                    StandardWatchEventKinds.ENTRY_MODIFY);
            WatchKey key = watchService.take(); // 等待直至有变化发生
            for (WatchEvent<?> event : key.pollEvents()) {
                // 检索事件种类和影响文件或目录
                System.out.println("Event kind: " + event.kind() +
                        ". File affected: " + event.context() + ".");
                if(event.kind() == StandardWatchEventKinds.ENTRY_CREATE) {
                    String filePath = path.toString()+'/'+event.context();
                    StringBuilder builder=new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            // 处理每一行
                            builder.append(line);
                        }
                        this.sendFile(builder.toString());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            boolean valid = key.reset(); // 重设 WatchKey 以便获取后续通知
            if (!valid) {
                break; // 如果 WatchKey 无效，则文件夹不可以访问，停止监控
            }
        }
    }
}
