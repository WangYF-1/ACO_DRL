本文件夹为前端文件夹，共包括6个文件，以及2个文件夹

README.md为前端项目安装说明文件，index.html为前端主程序入口，jsconfig.json、package-lock.json、package.json、vite.config.js项目依赖文件和配置文件

Src为项目源代码目录，public目录为网页图标目录

运行程序前请先查看README.md文件