import axios from "axios";
import {ElMessage} from "element-plus";


let Data={
    code: null,
    data: null,
    message:null
}

const defaultError = (error) => {
    console.error(error)
    ElMessage.error('发生了一些错误，请联系管理员')
}

const defaultFailure = (message, status, url) => {
    console.warn(`请求地址: ${url}, 状态码: ${status}, 错误信息: ${message}`)
    ElMessage.warning(message)
}

function get(url, success, failure = defaultFailure) {
    internalGet(url, success, failure)
}

function internalGet(url, success, failure, error = defaultError){
  axios.get(url).then(({data}) => {
      if(data.code === 200)
          success(data.data)
      else
          failure(data.message, data.code, url)
  }).catch(err => error(err))
}


function getList(type,success, failure = defaultFailure){
      get(`/api/getData?GroupId=${type}`, (data)=>{
          success(data)
      })
}

function getModel(type1,type2){
    downloadModel(type1,type2)
}

function downloadModel(GroupId, Round) {
    // 构造请求的URL
    const url = new URL('http://52.136.116.152:8080/api/Model');
    // 设置请求参数
    url.searchParams.append('GroupId', GroupId);
    url.searchParams.append('Round', Round);

    // 发起fetch请求
    fetch(url)
        .then(response => {
            // 确认请求成功
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.blob(); // 读取二进制数据
        })
        .then(blob => {
            // 使用Blob构造可下载的URL
            const url = window.URL.createObjectURL(blob);

            // 创建一个<a>元素用于触发下载
            const a = document.createElement('a');
            a.style.display = 'none'; // 隐藏元素
            a.href = url;  // 设置下载的URL
            a.download = 'model.txt'; // 设置下载时的文件名
            document.body.appendChild(a);  // 添加元素到页面中
            a.click();  // 触发下载

            // 清理：下载完成后，释放URL并移除<a>元素
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        })
        .catch(error => {
            console.error('Error during fetch:', error);
        });
}

function getBlockAndTransactionNumber(type,success, failure = defaultFailure){
    get(`/api/getBlockAndTransactionNumber?GroupId=${type}`, (data)=>{
        success(data)
    })
}

function getLength(type,success, failure = defaultFailure){
    get(`/api/getLength?GroupId=${type}`, (data)=>{
        success(data)
    })
}
export {getList,getModel,getBlockAndTransactionNumber,getLength};