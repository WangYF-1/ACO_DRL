<template>
  <router-view></router-view>
</template>
<script>
</script>
<style scoped>
*{
  margin-left: 10%;
  margin-right: 10%;
}
</style>

