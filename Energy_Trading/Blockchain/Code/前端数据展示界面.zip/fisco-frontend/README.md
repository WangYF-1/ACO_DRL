运行项目前请先使用下面的命令导入依赖包
npm install


下面为运行项目的命令（注：运行前请确保本地环境中包含Node 20、npm 10环境，确保端口5173未被占用。）
npm run dev

下面为服务器部署时，优化文件的命令
npm run build
